

<?php $__env->startSection('content'); ?>
<div class="w-full max-w-7xl mx-auto">

    <div class="mb-8">
        <h2 class="text-3xl font-black text-bgray-900 dark:text-white tracking-tight">Transaksi Baru</h2>
        <p class="text-sm font-medium text-bgray-500 dark:text-bgray-400">Kelola arus kas harian Anda dengan mudah.</p>
    </div>

    <div class="flex flex-col xl:flex-row gap-8 items-start">

        <div class="w-full xl:w-1/3 xl:sticky xl:top-24 z-10">

            <div class="relative overflow-hidden rounded-2xl bg-gradient-to-br from-indigo-600 to-violet-600 p-6 text-white shadow-xl shadow-indigo-200 dark:shadow-none mb-6 group">
                <div class="absolute -right-6 -top-6 h-32 w-32 rounded-full bg-white/10 blur-2xl transition-transform group-hover:scale-110 duration-700"></div>

                <div class="relative z-10">
                    <div class="flex items-center gap-3 mb-4">
                        <div class="flex h-12 w-12 items-center justify-center rounded-xl bg-white/20 backdrop-blur-md border border-white/10 shadow-inner">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M3 7V5a2 2 0 0 1 2-2h2" />
                                <path d="M17 3h2a2 2 0 0 1 2 2v2" />
                                <path d="M21 17v2a2 2 0 0 1-2 2h-2" />
                                <path d="M7 21H5a2 2 0 0 1-2-2v-2" />
                                <rect x="7" y="7" width="10" height="10" rx="1" />
                                <path d="M12 12h.01" /></svg>
                        </div>
                        <div>
                            <h4 class="font-bold text-lg leading-none">Scan Struk AI</h4>
                            <p class="text-[11px] text-indigo-100 opacity-80 mt-1">Otomatisasi input data belanja</p>
                        </div>
                    </div>

                    <form action="<?php echo e(route('transactions.scan')); ?>" method="POST" enctype="multipart/form-data" class="flex gap-2">
                        <?php echo csrf_field(); ?>
                        <div class="flex-1 relative">
                            <select name="wallet_id" class="w-full h-10 appearance-none rounded-lg border-none bg-black/20 pl-3 pr-8 text-xs font-bold text-white focus:ring-2 focus:ring-white/50 cursor-pointer">
                                <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($wallet->id); ?>" class="text-gray-900"><?php echo e($wallet->bank_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <div class="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 text-white/70">
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M6 9l6 6 6-6" /></svg>
                            </div>
                        </div>

                        <label class="cursor-pointer h-10 px-4 flex items-center justify-center rounded-lg bg-white text-indigo-700 text-xs font-bold hover:bg-indigo-50 transition shadow-sm active:scale-95">
                            <input type="file" name="receipt" class="hidden" onchange="this.form.submit()">
                            <span class="flex items-center gap-2">Upload <span class="text-base">📸</span></span>
                        </label>
                    </form>
                </div>
            </div>

            <div class="rounded-2xl bg-white p-1 dark:bg-darkblack-600 shadow-lg border border-bgray-100 dark:border-darkblack-400">

                <div class="flex p-1.5 bg-gray-100 dark:bg-darkblack-500 mb-6 border border-gray-200 dark:border-darkblack-400">

                    <!-- Tab Pemasukan -->
                    <button onclick="switchTab('income')" id="tab-income" class="w-1/2 flex items-center justify-center gap-2 py-3 text-sm font-semibold transition-all duration-300 ease-in-out
               bg-white text-success-400 shadow-md 
               dark:bg-darkblack-600 dark:text-success-300">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M12 19V5M5 12l7-7 7 7" />
                        </svg>
                        Pemasukan
                    </button>

                    <!-- Tab Pengeluaran -->
                    <button onclick="switchTab('expense')" id="tab-expense" class="w-1/2 flex items-center justify-center gap-2 py-3 text-sm font-semibold transition-all duration-300 ease-in-out
               text-gray-500 hover:text-gray-700">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M12 5v14M12 19l4-4M12 19l-4-4" />
                        </svg>
                        Pengeluaran
                    </button>

                </div>


                <div class="px-6 pb-6">
                    <?php if($errors->any()): ?>
                    <div class="mb-6 p-4 rounded-xl bg-red-50 border border-red-100 text-red-600 text-xs font-medium flex items-start gap-2">
                        <svg class="shrink-0" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="12" r="10" />
                            <line x1="12" y1="8" x2="12" y2="12" />
                            <line x1="12" y1="16" x2="12.01" y2="16" /></svg>
                        <ul class="list-none space-y-1">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <li><?php echo e($error); ?></li> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>

                    <style>
                        input[type=number]::-webkit-inner-spin-button,
                        input[type=number]::-webkit-outer-spin-button {
                            -webkit-appearance: none;
                            margin: 0;
                        }

                        input[type=number] {
                            -moz-appearance: textfield;
                        }

                    </style>

                    <div id="form-income" class="block animate-fade-in">
                        <form action="<?php echo e(route('income.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <div class="mb-6">
                                <label class="block text-xs font-bold text-bgray-400 uppercase tracking-wider mb-2">Nominal Masuk</label>
                                <div class="group relative flex items-center w-full rounded-2xl bg-gray-50 border-2 border-gray-100 focus-within:border-success-300 focus-within:bg-white focus-within:shadow-lg focus-within:shadow-success-100/20 transition-all duration-300 dark:bg-darkblack-500 dark:border-darkblack-400">
                                    <div class="pl-5 pr-2 pointer-events-none">
                                        <span class="text-2xl font-black text-gray-300 group-focus-within:text-success-400 transition-colors">Rp</span>
                                    </div>
                                    <input type="number" name="amount" class="w-full bg-transparent border-none py-5 pr-4 text-3xl font-black text-gray-900 placeholder-gray-200 focus:ring-0 dark:text-white dark:placeholder-gray-600" placeholder="0" required>
                                </div>
                            </div>

                            <div class="grid grid-cols-2 gap-4 mb-4">
                                <div>
                                    <div class="flex justify-between items-center mb-1">
                                        <label class="text-xs font-bold text-bgray-500">Ke Bank</label>
                                        <button type="button" onclick="addBank()" class="text-[10px] font-bold text-success-300 hover:underline">+ Baru</button>
                                    </div>
                                    <div class="relative">
                                        <select name="wallet_id" id="income_wallet_id" class="w-full h-12 appearance-none rounded-xl border-2 border-bgray-100 bg-white px-3 text-sm font-bold text-bgray-700 focus:border-success-300 focus:ring-0 dark:bg-darkblack-500 dark:border-darkblack-400 dark:text-white cursor-pointer transition-all">
                                            <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($wallet->id); ?>"><?php echo e($wallet->bank_name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <div class="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-bgray-400"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                <path d="M6 9l6 6 6-6" /></svg></div>
                                    </div>
                                </div>
                                <div>
                                    <div class="flex justify-between items-center mb-1">
                                        <label class="text-xs font-bold text-bgray-500">Kategori</label>
                                        <button type="button" onclick="addCategory('income')" class="text-[10px] font-bold text-success-300 hover:underline">+ Baru</button>
                                    </div>
                                    <div class="relative">
                                        <select name="category_id" id="income_category_id" class="w-full h-12 appearance-none rounded-xl border-2 border-bgray-100 bg-white px-3 text-sm font-bold text-bgray-700 focus:border-success-300 focus:ring-0 dark:bg-darkblack-500 dark:border-darkblack-400 dark:text-white cursor-pointer transition-all">
                                            <?php $__currentLoopData = $incomeCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(strtolower($cat->name) != 'pemasukan lainnya' && strtolower($cat->name) != 'lainnya'): ?>
                                            <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php $lainnyaIncome = $incomeCategories->firstWhere(fn($cat) => strtolower($cat->name) === 'pemasukan lainnya' || strtolower($cat->name) === 'lainnya'); ?>
                                            <?php if($lainnyaIncome): ?> <option value="<?php echo e($lainnyaIncome->id); ?>"><?php echo e($lainnyaIncome->name); ?></option> <?php endif; ?>
                                        </select>
                                        <div class="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-bgray-400"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                <path d="M6 9l6 6 6-6" /></svg></div>
                                    </div>
                                </div>
                            </div>

                            <div class="mb-6">
                                <label class="block text-xs font-bold text-bgray-500 mb-1.5">Detail Transaksi</label>
                                <div class="flex gap-3">
                                    <input type="date" name="date" value="<?php echo e(date('Y-m-d')); ?>" class="w-1/3 h-12 rounded-xl border-2 border-bgray-100 bg-white text-xs font-bold focus:border-success-300 focus:ring-0 dark:bg-darkblack-500 dark:border-darkblack-400 dark:text-white">
                                    <input type="text" name="description" placeholder="Catatan (Opsional)" class="w-2/3 h-12 rounded-xl border-2 border-bgray-100 bg-white px-4 text-xs font-bold focus:border-success-300 focus:ring-0 dark:bg-darkblack-500 dark:border-darkblack-400 dark:text-white">
                                </div>
                            </div>

                            <button type="submit" class="w-full h-12 rounded-xl bg-success-300 text-sm font-bold text-white shadow-lg shadow-success-300/30 hover:bg-success-400 hover:-translate-y-0.5 transition-all active:scale-95 flex items-center justify-center gap-2">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" />
                                    <polyline points="17 21 17 13 7 13 7 21" />
                                    <polyline points="7 3 7 8 15 8" /></svg>
                                Simpan Pemasukan
                            </button>
                        </form>
                    </div>

                    <div id="form-expense" class="hidden animate-fade-in">
                        <form action="<?php echo e(route('expense.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <div class="mb-6">
                                <label class="block text-xs font-bold text-bgray-400 uppercase tracking-wider mb-2">Nominal Keluar</label>
                                <div class="group relative flex items-center w-full rounded-2xl bg-gray-50 border-2 border-gray-100 focus-within:border-error-300 focus-within:bg-white focus-within:shadow-lg focus-within:shadow-error-100/20 transition-all duration-300 dark:bg-darkblack-500 dark:border-darkblack-400">
                                    <div class="pl-5 pr-2 pointer-events-none">
                                        <span class="text-2xl font-black text-gray-300 group-focus-within:text-error-400 transition-colors">Rp</span>
                                    </div>
                                    <input type="number" name="amount" class="w-full bg-transparent border-none py-5 pr-4 text-3xl font-black text-gray-900 placeholder-gray-200 focus:ring-0 dark:text-white dark:placeholder-gray-600" placeholder="0" required>
                                </div>
                            </div>

                            <div class="grid grid-cols-2 gap-4 mb-4">
                                <div>
                                    <div class="flex justify-between items-center mb-1">
                                        <label class="text-xs font-bold text-bgray-500">Dari Bank</label>
                                        <button type="button" onclick="addBank()" class="text-[10px] font-bold text-error-300 hover:underline">+ Baru</button>
                                    </div>
                                    <div class="relative">
                                        <select name="wallet_id" id="expense_wallet_id" class="w-full h-12 appearance-none rounded-xl border-2 border-bgray-100 bg-white px-3 text-sm font-bold text-bgray-700 focus:border-error-300 focus:ring-0 dark:bg-darkblack-500 dark:border-darkblack-400 dark:text-white cursor-pointer transition-all">
                                            <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($wallet->id); ?>"><?php echo e($wallet->bank_name); ?> (<?php echo e(number_format($wallet->balance)); ?>)</option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <div class="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-bgray-400"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                <path d="M6 9l6 6 6-6" /></svg></div>
                                    </div>
                                </div>
                                <div>
                                    <div class="flex justify-between items-center mb-1">
                                        <label class="text-xs font-bold text-bgray-500">Kategori</label>
                                        <button type="button" onclick="addCategory('expense')" class="text-[10px] font-bold text-error-300 hover:underline">+ Baru</button>
                                    </div>
                                    <div class="relative">
                                        <select name="category_id" id="expense_category_id" class="w-full h-12 appearance-none rounded-xl border-2 border-bgray-100 bg-white px-3 text-sm font-bold text-bgray-700 focus:border-error-300 focus:ring-0 dark:bg-darkblack-500 dark:border-darkblack-400 dark:text-white cursor-pointer transition-all">
                                            <?php $__currentLoopData = $expenseCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(strtolower($cat->name) != 'pengeluaran lainnya' && strtolower($cat->name) != 'lainnya'): ?>
                                            <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php $lainnyaExpense = $expenseCategories->firstWhere(fn($cat) => strtolower($cat->name) === 'pengeluaran lainnya' || strtolower($cat->name) === 'lainnya'); ?>
                                            <?php if($lainnyaExpense): ?> <option value="<?php echo e($lainnyaExpense->id); ?>"><?php echo e($lainnyaExpense->name); ?></option> <?php endif; ?>
                                        </select>
                                        <div class="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-bgray-400"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                <path d="M6 9l6 6 6-6" /></svg></div>
                                    </div>
                                </div>
                            </div>

                            <div class="mb-6">
                                <label class="block text-xs font-bold text-bgray-500 mb-1.5">Detail Transaksi</label>
                                <div class="flex gap-3">
                                    <input type="date" name="date" value="<?php echo e(date('Y-m-d')); ?>" class="w-1/3 h-12 rounded-xl border-2 border-bgray-100 bg-white text-xs font-bold focus:border-error-300 focus:ring-0 dark:bg-darkblack-500 dark:border-darkblack-400 dark:text-white">
                                    <input type="text" name="description" placeholder="Keperluan..." class="w-2/3 h-12 rounded-xl border-2 border-bgray-100 bg-white px-4 text-xs font-bold focus:border-error-300 focus:ring-0 dark:bg-darkblack-500 dark:border-darkblack-400 dark:text-white">
                                </div>
                            </div>

                            <button type="submit" class="w-full h-12 rounded-xl bg-error-300 text-sm font-bold text-white shadow-lg shadow-error-300/30 hover:bg-error-400 hover:-translate-y-0.5 transition-all active:scale-95 flex items-center justify-center gap-2">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" />
                                    <polyline points="17 21 17 13 7 13 7 21" />
                                    <polyline points="7 3 7 8 15 8" /></svg>
                                Simpan Pengeluaran
                            </button>
                        </form>
                    </div>

                </div>
            </div>
        </div>

        <div class="w-full xl:w-2/3">
            <div class="rounded-2xl bg-white p-6 dark:bg-darkblack-600 shadow-lg border border-bgray-100 dark:border-darkblack-400 h-full">
                <div class="flex justify-between items-center mb-6">
                    <div class="flex items-center gap-3">
                        <div class="h-10 w-10 flex items-center justify-center rounded-lg bg-bgray-100 text-bgray-500 dark:bg-darkblack-500 dark:text-white">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                                <polyline points="14 2 14 8 20 8"></polyline>
                                <line x1="16" y1="13" x2="8" y2="13"></line>
                                <line x1="16" y1="17" x2="8" y2="17"></line>
                                <polyline points="10 9 9 9 8 9"></polyline>
                            </svg>
                        </div>
                        <div>
                            <h3 class="text-lg font-bold text-bgray-900 dark:text-white">Riwayat Terbaru</h3>
                            <p class="text-xs text-bgray-500">Data transaksi <?php echo e(date('F Y')); ?></p>
                        </div>
                    </div>
                </div>

                <div class="overflow-x-auto">
                    <table class="w-full whitespace-nowrap">
                        <thead>
                            <tr class="text-left border-b border-bgray-100 dark:border-darkblack-400">
                                <th class="px-4 py-3 text-xs font-bold text-bgray-400 uppercase tracking-wider">Info</th>
                                <th class="px-4 py-3 text-xs font-bold text-bgray-400 uppercase tracking-wider">Akun</th>
                                <th class="px-4 py-3 text-right text-xs font-bold text-bgray-400 uppercase tracking-wider">Nominal</th>
                                <th class="px-4 py-3 text-center text-xs font-bold text-bgray-400 uppercase tracking-wider">Opsi</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-bgray-100 dark:divide-darkblack-500">
                            <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-bgray-50 dark:hover:bg-darkblack-500 transition-colors group">
                                <td class="px-4 py-4">
                                    <div class="flex items-center gap-4">
                                        <div class="flex h-10 w-10 shrink-0 items-center justify-center rounded-full <?php echo e($data->type == 'income' ? 'bg-success-50 text-success-300' : ($data->type == 'expense' ? 'bg-error-50 text-error-300' : 'bg-warning-50 text-warning-300')); ?>">
                                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                                <?php if($data->type == 'income'): ?>
                                                <path d="M12 19V5M5 12l7-7 7 7" />
                                                <?php elseif($data->type == 'expense'): ?>
                                                <path d="M12 5v14M12 19l4-4M12 19l-4-4" />
                                                <?php else: ?>
                                                <path d="M17 8L21 12L17 16M3 12H20M7 16L3 12L7 8" /> <?php endif; ?>
                                            </svg>
                                        </div>
                                        <div>
                                            <p class="text-sm font-bold text-bgray-900 dark:text-white"><?php echo e($data->category->name ?? 'Transfer'); ?></p>
                                            <p class="text-[11px] text-bgray-500"><?php echo e(\Carbon\Carbon::parse($data->date)->format('d M')); ?> • <?php echo e(Str::limit($data->description, 20)); ?></p>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-4 py-4">
                                    <span class="inline-block rounded-lg bg-bgray-50 border border-bgray-100 px-2.5 py-1 text-xs font-bold text-bgray-600 dark:bg-darkblack-500 dark:border-darkblack-400 dark:text-white">
                                        <?php echo e($data->wallet->bank_name); ?>

                                    </span>
                                </td>
                                <td class="px-4 py-4 text-right">
                                    <span class="text-sm font-black tracking-tight <?php echo e($data->type == 'income' ? 'text-success-300' : ($data->type == 'expense' ? 'text-error-300' : 'text-warning-300')); ?>">
                                        <?php echo e($data->type == 'income' ? '+' : ($data->type == 'expense' ? '-' : '')); ?>

                                        Rp <?php echo e(number_format($data->amount, 0, ',', '.')); ?>

                                    </span>
                                </td>
                                <td class="px-4 py-4 text-center">
                                    <div class="flex justify-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                        <a href="<?php echo e(route('transactions.edit', $data->id)); ?>" class="p-2 rounded-lg text-bgray-400 hover:text-warning-300 hover:bg-warning-50 transition-colors">
                                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                                                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" /></svg>
                                        </a>
                                        <form action="<?php echo e(route('transactions.destroy', $data->id)); ?>" method="POST" onsubmit="return confirm('Hapus?');">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="p-2 rounded-lg text-bgray-400 hover:text-error-300 hover:bg-error-50 transition-colors">
                                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                    <polyline points="3 6 5 6 21 6" />
                                                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" /></svg>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center py-12 text-gray-400 text-sm">
                                    <div class="flex flex-col items-center gap-2">
                                        <svg class="w-10 h-10 opacity-20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                                        </svg>
                                        Belum ada data transaksi.
                                    </div>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="mt-6">
                    <?php echo e($transactions->links('pagination::simple-tailwind')); ?>

                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    function switchTab(type) {
        const formIncome = document.getElementById('form-income');
        const formExpense = document.getElementById('form-expense');
        const tabIncome = document.getElementById('tab-income');
        const tabExpense = document.getElementById('tab-expense');

        // Kelas untuk tab Aktif (Putih + Shadow + Warna Teks)
        const activeClasses = ['bg-white', 'shadow-sm', 'dark:bg-darkblack-600'];
        // Kelas untuk tab Tidak Aktif (Transparan + Teks Abu)
        const inactiveClasses = ['text-gray-400', 'hover:text-gray-600'];

        if (type === 'income') {
            formIncome.classList.remove('hidden');
            formExpense.classList.add('hidden');

            // Style Tab Income (ACTIVE)
            tabIncome.classList.add(...activeClasses, 'text-success-300');
            tabIncome.classList.remove(...inactiveClasses);

            // Style Tab Expense (INACTIVE)
            tabExpense.classList.remove(...activeClasses, 'text-error-300');
            tabExpense.classList.add(...inactiveClasses);

        } else {
            formExpense.classList.remove('hidden');
            formIncome.classList.add('hidden');

            // Style Tab Expense (ACTIVE)
            tabExpense.classList.add(...activeClasses, 'text-error-300');
            tabExpense.classList.remove(...inactiveClasses);

            // Style Tab Income (INACTIVE)
            tabIncome.classList.remove(...activeClasses, 'text-success-300');
            tabIncome.classList.add(...inactiveClasses);
        }
    }

    // Set default active tab style
    document.addEventListener("DOMContentLoaded", function() {
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('tab') === 'expense') {
            switchTab('expense');
        } else {
            switchTab('income');
        }
    });

    async function addBank() {
        let name = prompt("Nama Bank Baru:");
        if (!name) return;
        let initialBalance = prompt("Saldo Awal (0 jika kosong):", "0");
        try {
            let response = await fetch("<?php echo e(route('wallets.storeAjax')); ?>", {
                method: "POST"
                , headers: {
                    "Content-Type": "application/json"
                    , "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"
                }
                , body: JSON.stringify({
                    bank_name: name
                    , balance: initialBalance
                })
            });
            let result = await response.json();
            if (result.success) {
                let newOption = new Option(result.data.bank_name, result.data.id, true, true);
                document.getElementById('income_wallet_id').add(newOption, undefined);
                document.getElementById('expense_wallet_id').add(newOption.cloneNode(true), undefined);
                alert("Bank ditambahkan!");
            }
        } catch (e) {
            alert("Gagal.");
        }
    }

    async function addCategory(type) {
        let name = prompt("Nama Kategori Baru:");
        if (!name) return;
        try {
            let response = await fetch("<?php echo e(route('categories.storeAjax')); ?>", {
                method: "POST"
                , headers: {
                    "Content-Type": "application/json"
                    , "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"
                }
                , body: JSON.stringify({
                    name: name
                    , type: type
                })
            });
            let result = await response.json();
            if (result.success) {
                let newOption = new Option(result.data.name, result.data.id, true, true);
                let targetId = type === 'income' ? 'income_category_id' : 'expense_category_id';
                document.getElementById(targetId).add(newOption, undefined);
                alert("Kategori ditambahkan!");
            }
        } catch (e) {
            alert("Gagal.");
        }
    }

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\finance-app\resources\views/transactions/index.blade.php ENDPATH**/ ?>