

<?php $__env->startSection('content'); ?>
<div class="w-full max-w-7xl mx-auto mt-8">
    
    <div class="mb-8 flex items-center gap-4">
        <div class="flex h-12 w-12 items-center justify-center rounded-full bg-warning-100 text-warning-300">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 8L21 12L17 16M3 12H20M7 16L3 12L7 8" /></svg>
        </div>
        <div>
            <h2 class="text-2xl font-bold text-bgray-900 dark:text-white">Transfer Antar Akun</h2>
            <p class="text-sm text-bgray-500 dark:text-bgray-300">Pindahkan dana dengan mudah & cepat.</p>
        </div>
    </div>

    <?php if($errors->any()): ?>
    <div class="mb-6 flex items-start gap-3 rounded-lg bg-error-50 p-4 text-error-300 border border-error-100">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10" /><line x1="12" y1="8" x2="12" y2="12" /><line x1="12" y1="16" x2="12.01" y2="16" /></svg>
        <div class="text-sm font-medium">
            <ul class="list-disc pl-4 space-y-1">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <li><?php echo e($error); ?></li> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
    <?php endif; ?>

    <div class="flex flex-col xl:flex-row gap-8">
        
        <div class="w-full xl:w-1/2">
            <div class="rounded-xl bg-white p-8 dark:bg-darkblack-600 shadow-lg border border-bgray-100 dark:border-darkblack-400">
                <form action="<?php echo e(route('transfer.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    
                    <style>
                        input[type=number]::-webkit-inner-spin-button, input[type=number]::-webkit-outer-spin-button { -webkit-appearance: none; margin: 0; }
                        input[type=number] { -moz-appearance: textfield; }
                    </style>

                    <div class="mb-8">
                        <label class="mb-3 block text-xs font-bold text-bgray-500 uppercase tracking-widest">Nominal Transfer</label>
                        <div class="group relative flex items-center w-full rounded-2xl bg-gray-50 border-2 border-gray-100 focus-within:border-warning-300 focus-within:bg-white focus-within:shadow-xl focus-within:shadow-warning-100/20 transition-all duration-300 ease-out dark:bg-darkblack-500 dark:border-darkblack-400">
                            <div class="pl-6 pr-4 pointer-events-none">
                                <span class="text-4xl font-black text-white group-focus-within:text-warning-400 transition-colors duration-300">Rp</span>
                            </div>
                            <input type="number" name="amount" class="w-full bg-transparent border-none py-6 pr-6 text-4xl font-black text-gray-900 placeholder-gray-200 focus:ring-0 dark:text-white dark:placeholder-gray-600" placeholder="0" required autofocus>
                        </div>
                        <div class="mt-2 flex justify-end"><p class="text-xs text-white">Minimal transfer Rp 10.000</p></div>
                    </div>

                    <div class="my-8 h-px w-full bg-bgray-200 dark:bg-darkblack-400"></div>

                    <div class="relative grid gap-6 md:grid-cols-2 mb-8 items-center">
                        <div>
                            <label class="mb-2 flex items-center gap-2 text-sm font-bold text-bgray-900 dark:text-white"><svg width="18" height="18" class="text-error-300" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 19V5M5 12l7-7 7 7" transform="rotate(180 12 12)" /></svg>Dari Akun (Sumber)</label>
                            <div class="relative">
                                <select name="source_wallet_id" class="w-full appearance-none rounded-lg border border-bgray-300 bg-white px-4 py-3.5 text-base font-medium text-bgray-900 focus:border-warning-300 focus:ring-2 focus:ring-warning-100 dark:border-darkblack-400 dark:bg-darkblack-500 dark:text-white transition-shadow cursor-pointer">
                                    <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($wallet->id); ?>"><?php echo e($wallet->bank_name); ?> — (Rp <?php echo e(number_format($wallet->balance, 0, ',', '.')); ?>)</option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <div class="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-bgray-400"></div>
                            </div>
                        </div>
                        <div class="hidden md:flex absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 items-center justify-center w-10 h-10 bg-warning-100 rounded-full text-warning-300 border border-warning-200 z-10 shadow-md">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ><path d="M5 12H19M19 12L12 5M19 12L12 19" /></svg>
                        </div>
                        <div>
                            <label class="mb-2 flex items-center gap-2 text-sm font-bold text-bgray-900 dark:text-white"><svg width="18" height="18" class="text-success-300" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 19V5M5 12l7-7 7 7" /></svg>Ke Akun (Tujuan)</label>
                            <div class="relative">
                                <select name="destination_wallet_id" class="w-full appearance-none rounded-lg border border-bgray-300 bg-white px-4 py-3.5 text-base font-medium text-bgray-900 focus:border-warning-300 focus:ring-2 focus:ring-warning-100 dark:border-darkblack-400 dark:bg-darkblack-500 dark:text-white transition-shadow cursor-pointer">
                                    <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($wallet->id); ?>"><?php echo e($wallet->bank_name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <div class="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-bgray-400"></div>
                            </div>
                        </div>
                    </div>

                    <div class="grid gap-6 md:grid-cols-2 mb-8">
                        <div>
                            <label class="mb-2 flex items-center gap-2 text-sm font-bold text-bgray-900 dark:text-white">Tanggal</label>
                            <input type="date" name="date" value="<?php echo e(date('Y-m-d')); ?>" class="w-full rounded-lg border border-bgray-300 px-4 py-3.5 text-base text-bgray-900 focus:border-warning-300 focus:ring-2 focus:ring-warning-100 dark:border-darkblack-400 dark:bg-darkblack-500 dark:text-white transition-shadow">
                        </div>
                        <div>
                            <label class="mb-2 flex items-center gap-2 text-sm font-bold text-bgray-900 dark:text-white">Catatan (Opsional)</label>
                            <input type="text" name="description" id="transfer-note" placeholder="Contoh: Nabung, Bayar Utang" class="w-full rounded-lg border border-bgray-300 px-4 py-3.5 text-base text-bgray-900 focus:border-warning-300 focus:ring-2 focus:ring-warning-100 dark:border-darkblack-400 dark:bg-darkblack-500 dark:text-white transition-shadow">
                        </div>
                    </div>

                    <div class="flex items-center justify-end gap-4 pt-4">
                        <a href="<?php echo e(route('dashboard')); ?>" class="rounded-lg px-6 py-3 text-sm font-bold text-bgray-500 hover:bg-bgray-100 hover:text-bgray-900 transition-colors">Batal</a>
                        <button type="submit" class="flex items-center gap-2 rounded-lg bg-warning-300 px-8 py-3 text-base font-bold text-white shadow-lg shadow-warning-300/30 transition-all hover:bg-warning-400 hover:shadow-warning-400/40 active:scale-95">
                            <span>Proses Transfer</span>
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14" /><path d="M12 5l7 7-7 7" /></svg>
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <div class="w-full xl:w-1/2">
            <div class="rounded-xl bg-white p-6 dark:bg-darkblack-600 shadow-sm border border-bgray-100 dark:border-darkblack-400">
                <div class="flex justify-between items-center mb-6">
                    <h3 class="text-lg font-bold text-bgray-900 dark:text-white">Mutasi Terakhir</h3>
                    <a href="<?php echo e(route('transactions.index')); ?>" class="text-sm font-bold text-blue-500 hover:text-blue-600">Lihat Semua</a>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full whitespace-nowrap">
                        <thead>
                            <tr class="text-left border-b border-bgray-100 dark:border-darkblack-400">
                                <th class="px-4 py-3 text-xs font-bold text-bgray-400 uppercase tracking-wider">Detail</th>
                                <th class="px-4 py-3 text-xs font-bold text-bgray-400 uppercase tracking-wider">Bank</th>
                                <th class="px-4 py-3 text-right text-xs font-bold text-bgray-400 uppercase tracking-wider">Jumlah</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-bgray-100 dark:divide-darkblack-500">
                            <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php $isSource = $data->type == 'expense' || $data->type == 'transfer'; ?>
                                <tr class="hover:bg-bgray-50 dark:hover:bg-darkblack-500 transition-colors">
                                    <td class="px-4 py-4">
                                        <div class="flex items-center gap-4">
                                            <div class="flex h-10 w-10 shrink-0 items-center justify-center rounded-full <?php echo e($isSource ? 'bg-error-50 text-error-300' : 'bg-success-50 text-success-300'); ?>">
                                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                                    <?php if($isSource): ?> <path d="M12 5v14M12 19l4-4M12 19l-4-4"/> <?php else: ?> <path d="M12 19V5M5 12l7-7 7 7"/> <?php endif; ?>
                                                </svg>
                                            </div>
                                            <div>
                                                <p class="text-sm font-bold text-bgray-900 dark:text-white"><?php echo e($isSource ? 'Keluar' : 'Masuk'); ?> (<?php echo e($data->category->name ?? 'Transfer'); ?>)</p>
                                                <p class="text-[11px] text-bgray-500"><?php echo e($data->date->format('d M')); ?> • <?php echo e(Str::limit($data->description, 20)); ?></p>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-4 py-4">
                                        <span class="inline-block rounded-lg bg-bgray-50 border border-bgray-100 px-2.5 py-1 text-xs font-bold text-bgray-600 dark:bg-darkblack-500 dark:border-darkblack-400 dark:text-white"><?php echo e($data->wallet->bank_name); ?></span>
                                    </td>
                                    <td class="px-4 py-4 text-right">
                                        <span class="text-sm font-black tracking-tight <?php echo e($isSource ? 'text-error-300' : 'text-success-300'); ?>"><?php echo e($isSource ? '-' : '+'); ?> Rp <?php echo e(number_format($data->amount, 0, ',', '.')); ?></span>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="3" class="text-center py-8 text-gray-400 text-sm">Belum ada mutasi terbaru.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // --- SCRIPT ANTI BUG HURUF K & B ---
    document.addEventListener('keydown', function(e) {
        const activeElement = document.activeElement;
        
        // Jika user sedang mengetik di input catatan transfer
        if (activeElement && activeElement.id === 'transfer-note') {
            if (e.key.toLowerCase() === 'k' || e.key.toLowerCase() === 'b') {
                e.stopPropagation(); // Hentikan shortcut global
            }
        }
    }, true); // Mode capturing (Prioritas Tinggi)
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\finance-app\resources\views/transactions/create_transfer.blade.php ENDPATH**/ ?>